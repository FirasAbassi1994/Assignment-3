import "./App.css";
import CurrencySelector from "./components/CurrencySelector";
import contractABI from "./contracts/currency.json";

// Replace with your contract address
const contractAddress = "0x35Ea23AA0e572A285730b658526b4407Ae02006A";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Name : Firas Abassi </p>
        <p>Student ID : 101266790 </p>
        <p>Module Code and Name: BCDV 4023 - Full Stack Blockchain Integration I</p>
        <p>Assignment number: Assignment 03</p>
        <p>Date : 17th December 2023</p>
        <h1>4 Currency Conversion Crypto Project</h1>
        <h1>Decentralized Application dapp</h1>
        <CurrencySelector
          contractAddress={contractAddress}
          contractABI={contractABI}
        />
      </header>
    </div>
  );
}

export default App;
