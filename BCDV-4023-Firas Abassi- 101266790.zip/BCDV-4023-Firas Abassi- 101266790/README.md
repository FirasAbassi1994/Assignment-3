Name: Firas Abssi
Student ID: 101266790
Currecny Conversion Crypto Project
Assignment 3